make
strip src/.libs/*.dll
xbecopy src/.libs/libdvdnav-4.dll xe:\\xbmc\\system\\players\\dvdplayer\\libdvdnav.dll