make
makedll
xbecopy libdvdcss-2.dll xe:\\xbmc\\system\\players\\dvdplayer\\libdvdcss-2.dll
