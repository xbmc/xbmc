
#./autogen.sh

export CFLAGS="-D_XBOX -DNDEBUG"

#./configure --enable-shared --disable-static
./configure

