//#include <H:\Microsoft Xbox SDK\xbox\include\xtl.h>
#include <windows.h>
#include <conio.h>
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <math.h>
#include <mmsystem.h>
#include <d3d8.h>
#include <d3dx8.h>
