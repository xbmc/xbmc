#pragma warning (disable:4391)
#pragma warning (disable:4392)

/*
#ifdef GLOBAL_SCOPE
extern "C" void dll_close(void);
#else
Exp2Dll* MSVCR71_exp1 = new Exp2Dll("MSVCR71.dll", "_close", (unsigned long)dll_close);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_lseek(void);
#else
Exp2Dll* MSVCR71_exp2 = new Exp2Dll("MSVCR71.dll", "_lseek", (unsigned long)dll_lseek);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_read(void);
#else
Exp2Dll* MSVCR71_exp3 = new Exp2Dll("MSVCR71.dll", "_read", (unsigned long)dll_read);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_write(void);
#else
Exp2Dll* MSVCR71_exp4 = new Exp2Dll("MSVCR71.dll", "_write", (unsigned long)dll_write);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll__dllonexit(void);
#else
Exp2Dll* MSVCR71_exp5 = new Exp2Dll("MSVCR71.dll", "__dllonexit", (unsigned long)dll__dllonexit);
#endif
*/
#ifdef GLOBAL_SCOPE
extern "C" void __mb_cur_max(void);
#else
Exp2Dll* MSVCR71_exp6 = new Exp2Dll("MSVCR71.dll", "__mb_cur_max", (unsigned long)__mb_cur_max);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _assert(void);
#else
Exp2Dll* MSVCR71_exp7 = new Exp2Dll("MSVCR71.dll", "_assert", (unsigned long)_assert);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _errno(void);
#else
Exp2Dll* MSVCR71_exp8 = new Exp2Dll("MSVCR71.dll", "_errno", (unsigned long)_errno);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _ftime(void);
#else
Exp2Dll* MSVCR71_exp9 = new Exp2Dll("MSVCR71.dll", "_ftime", (unsigned long)_ftime);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _iob(void);
#else
Exp2Dll* MSVCR71_exp10 = new Exp2Dll("MSVCR71.dll", "_iob", (unsigned long)_iob);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _isctype(void);
#else
Exp2Dll* MSVCR71_exp11 = new Exp2Dll("MSVCR71.dll", "_isctype", (unsigned long)_isctype);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_lseeki64(void);
#else
Exp2Dll* MSVCR71_exp12 = new Exp2Dll("MSVCR71.dll", "_lseeki64", (unsigned long)dll_lseeki64);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_open(void);
#else
Exp2Dll* MSVCR71_exp13 = new Exp2Dll("MSVCR71.dll", "_open", (unsigned long)dll_open);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _snprintf(void);
#else
Exp2Dll* MSVCR71_exp14 = new Exp2Dll("MSVCR71.dll", "_snprintf", (unsigned long)_snprintf);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _stricmp(void);
#else
Exp2Dll* MSVCR71_exp15 = new Exp2Dll("MSVCR71.dll", "_stricmp", (unsigned long)_stricmp);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _strnicmp(void);
#else
Exp2Dll* MSVCR71_exp16 = new Exp2Dll("MSVCR71.dll", "_strnicmp", (unsigned long)_strnicmp);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _vsnprintf(void);
#else
Exp2Dll* MSVCR71_exp17 = new Exp2Dll("MSVCR71.dll", "_vsnprintf", (unsigned long)_vsnprintf);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void abort(void);
#else
Exp2Dll* MSVCR71_exp18 = new Exp2Dll("MSVCR71.dll", "abort", (unsigned long)abort);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void atof(void);
#else
Exp2Dll* MSVCR71_exp19 = new Exp2Dll("MSVCR71.dll", "atof", (unsigned long)atof);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void atoi(void);
#else
Exp2Dll* MSVCR71_exp20 = new Exp2Dll("MSVCR71.dll", "atoi", (unsigned long)atoi);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void cos(void);
#else
Exp2Dll* MSVCR71_exp21 = new Exp2Dll("MSVCR71.dll", "cos", (unsigned long)cos);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void cosh(void);
#else
Exp2Dll* MSVCR71_exp22 = new Exp2Dll("MSVCR71.dll", "cosh", (unsigned long)cosh);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void exp(void);
#else
Exp2Dll* MSVCR71_exp23 = new Exp2Dll("MSVCR71.dll", "exp", (unsigned long)exp);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void fflush(void);
#else
Exp2Dll* MSVCR71_exp24 = new Exp2Dll("MSVCR71.dll", "fflush", (unsigned long)fflush);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void floor(void);
#else
Exp2Dll* MSVCR71_exp25 = new Exp2Dll("MSVCR71.dll", "floor", (unsigned long)floor);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void fprintf(void);
#else
Exp2Dll* MSVCR71_exp26 = new Exp2Dll("MSVCR71.dll", "fprintf", (unsigned long)fprintf);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void free(void);
#else
Exp2Dll* MSVCR71_exp27 = new Exp2Dll("MSVCR71.dll", "free", (unsigned long)free);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void frexp(void);
#else
Exp2Dll* MSVCR71_exp28 = new Exp2Dll("MSVCR71.dll", "frexp", (unsigned long)frexp);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void fwrite(void);
#else
Exp2Dll* MSVCR71_exp29 = new Exp2Dll("MSVCR71.dll", "fwrite", (unsigned long)fwrite);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void gmtime(void);
#else
Exp2Dll* MSVCR71_exp30 = new Exp2Dll("MSVCR71.dll", "gmtime", (unsigned long)gmtime);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void ldexp(void);
#else
Exp2Dll* MSVCR71_exp31 = new Exp2Dll("MSVCR71.dll", "ldexp", (unsigned long)ldexp);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void localtime(void);
#else
Exp2Dll* MSVCR71_exp32 = new Exp2Dll("MSVCR71.dll", "localtime", (unsigned long)localtime);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void log(void);
#else
Exp2Dll* MSVCR71_exp33 = new Exp2Dll("MSVCR71.dll", "log", (unsigned long)log);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void log10(void);
#else
Exp2Dll* MSVCR71_exp34 = new Exp2Dll("MSVCR71.dll", "log10", (unsigned long)log10);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void malloc(void);
#else
Exp2Dll* MSVCR71_exp35 = new Exp2Dll("MSVCR71.dll", "malloc", (unsigned long)malloc);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void memcpy(void);
#else
Exp2Dll* MSVCR71_exp36 = new Exp2Dll("MSVCR71.dll", "memcpy", (unsigned long)memcpy);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void memmove(void);
#else
Exp2Dll* MSVCR71_exp37 = new Exp2Dll("MSVCR71.dll", "memmove", (unsigned long)memmove);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void memset(void);
#else
Exp2Dll* MSVCR71_exp38 = new Exp2Dll("MSVCR71.dll", "memset", (unsigned long)memset);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void mktime(void);
#else
Exp2Dll* MSVCR71_exp39 = new Exp2Dll("MSVCR71.dll", "mktime", (unsigned long)mktime);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void perror(void);
#else
Exp2Dll* MSVCR71_exp40 = new Exp2Dll("MSVCR71.dll", "perror", (unsigned long)perror);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dllprintf(void);
#else
Exp2Dll* MSVCR71_exp41 = new Exp2Dll("MSVCR71.dll", "printf", (unsigned long)dllprintf);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void putchar(void);
#else
Exp2Dll* MSVCR71_exp42 = new Exp2Dll("MSVCR71.dll", "putchar", (unsigned long)putchar);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dllputs(void);
#else
Exp2Dll* MSVCR71_exp43 = new Exp2Dll("MSVCR71.dll", "puts", (unsigned long)dllputs);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void qsort(void);
#else
Exp2Dll* MSVCR71_exp44 = new Exp2Dll("MSVCR71.dll", "qsort", (unsigned long)qsort);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void realloc(void);
#else
Exp2Dll* MSVCR71_exp45 = new Exp2Dll("MSVCR71.dll", "realloc", (unsigned long)realloc);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void sin(void);
#else
Exp2Dll* MSVCR71_exp46 = new Exp2Dll("MSVCR71.dll", "sin", (unsigned long)sin);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void sinh(void);
#else
Exp2Dll* MSVCR71_exp47 = new Exp2Dll("MSVCR71.dll", "sinh", (unsigned long)sinh);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void sprintf(void);
#else
Exp2Dll* MSVCR71_exp48 = new Exp2Dll("MSVCR71.dll", "sprintf", (unsigned long)sprintf);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void sqrt(void);
#else
Exp2Dll* MSVCR71_exp49 = new Exp2Dll("MSVCR71.dll", "sqrt", (unsigned long)sqrt);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void sscanf(void);
#else
Exp2Dll* MSVCR71_exp50 = new Exp2Dll("MSVCR71.dll", "sscanf", (unsigned long)sscanf);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strchr(void);
#else
Exp2Dll* MSVCR71_exp51 = new Exp2Dll("MSVCR71.dll", "strchr", (unsigned long)strchr);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strcmp(void);
#else
Exp2Dll* MSVCR71_exp52 = new Exp2Dll("MSVCR71.dll", "strcmp", (unsigned long)strcmp);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strcpy(void);
#else
Exp2Dll* MSVCR71_exp53 = new Exp2Dll("MSVCR71.dll", "strcpy", (unsigned long)strcpy);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strlen(void);
#else
Exp2Dll* MSVCR71_exp54 = new Exp2Dll("MSVCR71.dll", "strlen", (unsigned long)strlen);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strncpy(void);
#else
Exp2Dll* MSVCR71_exp55 = new Exp2Dll("MSVCR71.dll", "strncpy", (unsigned long)strncpy);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strrchr(void);
#else
Exp2Dll* MSVCR71_exp56 = new Exp2Dll("MSVCR71.dll", "strrchr", (unsigned long)strrchr);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strtod(void);
#else
Exp2Dll* MSVCR71_exp57 = new Exp2Dll("MSVCR71.dll", "strtod", (unsigned long)strtod);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strtok(void);
#else
Exp2Dll* MSVCR71_exp58 = new Exp2Dll("MSVCR71.dll", "strtok", (unsigned long)strtok);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strtol(void);
#else
Exp2Dll* MSVCR71_exp59 = new Exp2Dll("MSVCR71.dll", "strtol", (unsigned long)strtol);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strtoul(void);
#else
Exp2Dll* MSVCR71_exp60 = new Exp2Dll("MSVCR71.dll", "strtoul", (unsigned long)strtoul);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void tan(void);
#else
Exp2Dll* MSVCR71_exp61 = new Exp2Dll("MSVCR71.dll", "tan", (unsigned long)tan);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void tanh(void);
#else
Exp2Dll* MSVCR71_exp62 = new Exp2Dll("MSVCR71.dll", "tanh", (unsigned long)tanh);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void time(void);
#else
Exp2Dll* MSVCR71_exp63 = new Exp2Dll("MSVCR71.dll", "time", (unsigned long)time);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void toupper(void);
#else
Exp2Dll* MSVCR71_exp64 = new Exp2Dll("MSVCR71.dll", "toupper", (unsigned long)toupper);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _memccpy(void);
#else
Exp2Dll* MSVCR71_exp65 = new Exp2Dll("MSVCR71.dll", "_memccpy", (unsigned long)_memccpy);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _fstat(void);
#else
Exp2Dll* MSVCR71_exp66 = new Exp2Dll("MSVCR71.dll", "_fstat", (unsigned long)_fstat);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _memccpy(void);
#else
Exp2Dll* MSVCR71_exp67 = new Exp2Dll("MSVCR71.dll", "_memccpy", (unsigned long)_memccpy);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _mkdir(void);
#else
Exp2Dll* MSVCR71_exp68 = new Exp2Dll("MSVCR71.dll", "_mkdir", (unsigned long)_mkdir);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _pclose(void);
#else
Exp2Dll* MSVCR71_exp69 = new Exp2Dll("MSVCR71.dll", "_pclose", (unsigned long)_pclose);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _popen(void);
#else
Exp2Dll* MSVCR71_exp70 = new Exp2Dll("MSVCR71.dll", "_popen", (unsigned long)_popen);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_sleep(void);
#else
Exp2Dll* MSVCR71_exp71 = new Exp2Dll("MSVCR71.dll", "_sleep", (unsigned long)dll_sleep);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _stat(void);
#else
Exp2Dll* MSVCR71_exp72 = new Exp2Dll("MSVCR71.dll", "_stat", (unsigned long)_stat);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _strdup(void);
#else
Exp2Dll* MSVCR71_exp73 = new Exp2Dll("MSVCR71.dll", "_strdup", (unsigned long)_strdup);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _swab(void);
#else
Exp2Dll* MSVCR71_exp74 = new Exp2Dll("MSVCR71.dll", "_swab", (unsigned long)_swab);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _findclose(void);
#else
Exp2Dll* MSVCR71_exp75 = new Exp2Dll("MSVCR71.dll", "_findclose", (unsigned long)_findclose);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _findfirst(void);
#else
Exp2Dll* MSVCR71_exp76 = new Exp2Dll("MSVCR71.dll", "_findfirst", (unsigned long)_findfirst);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _findnext(void);
#else
Exp2Dll* MSVCR71_exp77 = new Exp2Dll("MSVCR71.dll", "_findnext", (unsigned long)_findnext);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _fullpath(void);
#else
Exp2Dll* MSVCR71_exp78 = new Exp2Dll("MSVCR71.dll", "_fullpath", (unsigned long)_fullpath);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _pctype(void);
#else
Exp2Dll* MSVCR71_exp79 = new Exp2Dll("MSVCR71.dll", "_pctype", (unsigned long)_pctype);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void calloc(void);
#else
Exp2Dll* MSVCR71_exp80 = new Exp2Dll("MSVCR71.dll", "calloc", (unsigned long)calloc);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void ceil(void);
#else
Exp2Dll* MSVCR71_exp81 = new Exp2Dll("MSVCR71.dll", "ceil", (unsigned long)ceil);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void ctime(void);
#else
Exp2Dll* MSVCR71_exp82 = new Exp2Dll("MSVCR71.dll", "ctime", (unsigned long)ctime);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void exit(void);
#else
Exp2Dll* MSVCR71_exp83 = new Exp2Dll("MSVCR71.dll", "exit", (unsigned long)exit);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_fclose(void);
#else
Exp2Dll* MSVCR71_exp84 = new Exp2Dll("MSVCR71.dll", "fclose", (unsigned long)dll_fclose);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_feof(void);
#else
Exp2Dll* MSVCR71_exp85 = new Exp2Dll("MSVCR71.dll", "feof", (unsigned long)dll_feof);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_fgets(void);
#else
Exp2Dll* MSVCR71_exp86 = new Exp2Dll("MSVCR71.dll", "fgets", (unsigned long)dll_fgets);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_fopen(void);
#else
Exp2Dll* MSVCR71_exp87 = new Exp2Dll("MSVCR71.dll", "fopen", (unsigned long)dll_fopen);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_fputc(void);
#else
Exp2Dll* MSVCR71_exp88 = new Exp2Dll("MSVCR71.dll", "fputc", (unsigned long)dll_fputc);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_fputs(void);
#else
Exp2Dll* MSVCR71_exp89 = new Exp2Dll("MSVCR71.dll", "fputs", (unsigned long)dll_fputs);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_fread(void);
#else
Exp2Dll* MSVCR71_exp90 = new Exp2Dll("MSVCR71.dll", "fread", (unsigned long)dll_fread);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_fseek(void);
#else
Exp2Dll* MSVCR71_exp91 = new Exp2Dll("MSVCR71.dll", "fseek", (unsigned long)dll_fseek);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_ftell(void);
#else
Exp2Dll* MSVCR71_exp92 = new Exp2Dll("MSVCR71.dll", "ftell", (unsigned long)dll_ftell);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void dll_getc(void);
#else
Exp2Dll* MSVCR71_exp93 = new Exp2Dll("MSVCR71.dll", "getc", (unsigned long)dll_getc);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void getenv(void);
#else
Exp2Dll* MSVCR71_exp94 = new Exp2Dll("MSVCR71.dll", "getenv", (unsigned long)getenv);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void putc(void);
#else
Exp2Dll* MSVCR71_exp95 = new Exp2Dll("MSVCR71.dll", "putc", (unsigned long)putc);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void rand(void);
#else
Exp2Dll* MSVCR71_exp96 = new Exp2Dll("MSVCR71.dll", "rand", (unsigned long)rand);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void remove(void);
#else
Exp2Dll* MSVCR71_exp97 = new Exp2Dll("MSVCR71.dll", "remove", (unsigned long)remove);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void rewind(void);
#else
Exp2Dll* MSVCR71_exp98 = new Exp2Dll("MSVCR71.dll", "rewind", (unsigned long)rewind);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void setlocale(void);
#else
Exp2Dll* MSVCR71_exp99 = new Exp2Dll("MSVCR71.dll", "setlocale", (unsigned long)setlocale);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void signal(void);
#else
Exp2Dll* MSVCR71_exp100 = new Exp2Dll("MSVCR71.dll", "signal", (unsigned long)signal);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void srand(void);
#else
Exp2Dll* MSVCR71_exp101 = new Exp2Dll("MSVCR71.dll", "srand", (unsigned long)srand);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strcat(void);
#else
Exp2Dll* MSVCR71_exp102 = new Exp2Dll("MSVCR71.dll", "strcat", (unsigned long)strcat);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strcoll(void);
#else
Exp2Dll* MSVCR71_exp103 = new Exp2Dll("MSVCR71.dll", "strcoll", (unsigned long)strcoll);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strerror(void);
#else
Exp2Dll* MSVCR71_exp104 = new Exp2Dll("MSVCR71.dll", "strerror", (unsigned long)strerror);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strncat(void);
#else
Exp2Dll* MSVCR71_exp105 = new Exp2Dll("MSVCR71.dll", "strncat", (unsigned long)strncat);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strncmp(void);
#else
Exp2Dll* MSVCR71_exp106 = new Exp2Dll("MSVCR71.dll", "strncmp", (unsigned long)strncmp);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strpbrk(void);
#else
Exp2Dll* MSVCR71_exp107 = new Exp2Dll("MSVCR71.dll", "strpbrk", (unsigned long)strpbrk);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void strstr(void);
#else
Exp2Dll* MSVCR71_exp108 = new Exp2Dll("MSVCR71.dll", "strstr", (unsigned long)strstr);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void tolower(void);
#else
Exp2Dll* MSVCR71_exp109 = new Exp2Dll("MSVCR71.dll", "tolower", (unsigned long)tolower);
#endif

#ifdef GLOBAL_SCOPE
extern "C" void acos(void);
#else
Exp2Dll* MSVCR71_exp110 = new Exp2Dll("MSVCR71.dll", "acos", (unsigned long)acos);
#endif


#ifdef GLOBAL_SCOPE
extern "C" void atan(void);
#else
Exp2Dll* MSVCR71_exp111 = new Exp2Dll("MSVCR71.dll", "atan", (unsigned long)atan);
#endif


#ifdef GLOBAL_SCOPE
extern "C" void memchr(void);
#else
Exp2Dll* MSVCR71_exp112 = new Exp2Dll("MSVCR71.dll", "memchr", (unsigned long)memchr);
#endif

#ifdef GLOBAL_SCOPE
extern "C" void isdigit(void);
#else
Exp2Dll* MSVCR71_exp113 = new Exp2Dll("MSVCR71.dll", "isdigit", (unsigned long)isdigit);
#endif


#ifdef GLOBAL_SCOPE
extern "C" void dll_strcmpi(void);
#else
Exp2Dll* MSVCR71_exp114 = new Exp2Dll("MSVCR71.dll", "_strcmpi", (unsigned long)dll_strcmpi);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _CIpow(void);
#else
Exp2Dll* MSVCR71_exp115 = new Exp2Dll("MSVCR71.dll", "_CIpow", (unsigned long)_CIpow);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void _adjust_fdiv(void);
#else
Exp2Dll* MSVCR71_exp116 = new Exp2Dll("MSVCR71.dll", "_adjust_fdiv", (unsigned long)_adjust_fdiv);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void pow(void);
#else
Exp2Dll* MSVCR71_exp117 = new Exp2Dll("MSVCR71.dll", "pow", (unsigned long)pow);
#endif
#ifdef GLOBAL_SCOPE
extern "C" void fabs(void);
#else
Exp2Dll* MSVCR71_exp118 = new Exp2Dll("MSVCR71.dll", "fabs", (unsigned long)fabs);
#endif
