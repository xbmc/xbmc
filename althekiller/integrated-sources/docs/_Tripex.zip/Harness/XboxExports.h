#ifndef _XBOXEXPORTS_H
#define _XBOXEXPORTS_H

namespace XboxExports
{
	// Init( ):
	void Init( );
};

#endif