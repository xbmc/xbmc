#include "StdAfx.h"
#include "effect.h"
#include "config-variables.h"
#include "ZTripex.h"
#include "xbmc.h"

IDirect3DDevice8 *g_pd3dDevice;
//unsigned char g_pcSpectrum[ 2 ][ 576 ];
//unsigned char g_pcWaveform[ 2 ][ 576 ];

HRESULT TxStartup( );
HRESULT TxRender( );
void TxShutdown( HRESULT );

BOOL g_bInit = FALSE;

ZTripex *g_pTripex;

//void _cdecl Create( IDirect3DDevice8 *pd3dDevice )
void _cdecl Create( LPDIRECT3DDEVICE8 pd3dDevice, int iWidth, int iHeight, const char* szVisualisationName)
{
	g_pd3dDevice = pd3dDevice;
	g_bInit = FALSE;
}

//void _cdecl Start( int iChannels, int iSamplesPerSec, int iBitsPerSample )
void _cdecl Start( int iChannels, int iSamplesPerSec, int iBitsPerSample, const char* szSongName)
{
	printf("start\n" );
	//TODO:
	g_pTripex = new ZTripex;

	printf("constructed ZTripex\n" );

	CreateEffectList( );
	CreateCfgItems( );

	printf("calling Startup( )\n" );

	HRESULT hRes = g_pTripex->Startup( );
	if( FAILED( hRes ) ) 
	{
		printf("Startup( ) failed\n" );
		g_pTripex->Shutdown( );
		g_bInit = FALSE;
	}
	else
	{
		printf("Startup( ) succeeded\n" );
		g_bInit = TRUE;
	}
}

void _cdecl AudioData( short* pAudioData, int iAudioDataLength, float *pFreqData, int iFreqDataLength )
{
	if( g_pAudio != NULL )
	{
		g_pAudio->SetDataFormat( 2, 44100, 16 );
		g_pAudio->AddData( pAudioData, iAudioDataLength );
	}

//	for( int i = 0; i < 2; i++ )
//	{
//		for( int j = 0; j < 576; j++ )
//		{
//			g_pcSpectrum[ i ][ j ] = 0.6f * rand( ) / powf(j, 1.4f);
//			//	powf( rand( ), 1.0f + ( 4.0f * -j / 576.0f ) );
//			g_pcWaveform[ i ][ j ] = rand( );
//		}
//	}
}

void _cdecl Render( )
{
	if( g_bInit )
	{
		HRESULT hRes = g_pTripex->Render( );
		if( FAILED( hRes ) )
		{
			g_pTripex->Shutdown( );
			g_bInit = FALSE;
		}
	}
}

void _cdecl Stop( )
{
	if( g_bInit )
	{
		g_pTripex->Shutdown( );
		g_bInit = FALSE;
	}
}

void _cdecl GetInfo( VIS_INFO *pInfo )
{
	pInfo->bWantsFreq = TRUE;
	pInfo->iSyncDelay = 0;
}

extern "C" __declspec( dllexport ) void get_module( struct VISUALISATION *pVis )
{
	pVis->Create = Create;
	pVis->Start = Start;
	pVis->AudioData = AudioData;
	pVis->Render = Render;
	pVis->Stop = Stop;
	pVis->GetInfo = GetInfo;
}
