#ifndef _ZPALETTE_H
#define _ZPALETTE_H

class ZPalette
{
public:
	PALETTEENTRY m_aPalette[ 256 ];



};

#endif