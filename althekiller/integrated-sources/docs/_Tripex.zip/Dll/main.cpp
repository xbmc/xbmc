#include "StdAfx.h"
#include "ZAudio.h"

ZAudio *g_pAudio = NULL;
