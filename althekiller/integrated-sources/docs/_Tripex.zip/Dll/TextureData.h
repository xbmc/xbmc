#pragma once

extern const UINT32 g_anTexRawGUI[ ];
extern const UINT32 g_anTexRawFont[ ];
extern const UINT32 g_anTexBlank[ ];
extern const UINT32 g_anTexAlienEgg[ ];
extern const UINT32 g_anTexBrightLight[ ];
extern const UINT32 g_anTexEyes[ ];
extern const UINT32 g_anTexFlesh[ ];
extern const UINT32 g_anTexForest[ ];
extern const UINT32 g_anTexLight[ ];
extern const UINT32 g_anTexShinySand[ ];
