#pragma once

int GetDefaultInt(const char *sName);
const char *GetDefaultStr(const char *sName);

