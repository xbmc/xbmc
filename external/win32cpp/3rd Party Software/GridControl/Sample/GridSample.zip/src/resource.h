//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDW_MAIN                        51
#define IDW_ABOUT                       52
#define IDW_VIEW_TOOLBAR                53
#define IDW_VIEW_STATUSBAR              54
#define IDW_CMD_BANDS                   55
#define IDW_MENUBAR                     56
#define IDW_TOOLBAR                     57
#define IDW_QUIT                        58
#define IDW_MDI_CASCADE                 60
#define IDW_MDI_TILE                    61
#define IDW_MDI_ARRANGE                 62
#define IDW_MDI_CLOSEALL                63
#define IDW_FIRSTCHILD                  64
#define IDW_CHILD2                      65
#define IDW_CHILD3                      66
#define IDW_CHILD4                      67
#define IDW_CHILD5                      68
#define IDW_CHILD6                      69
#define IDW_CHILD7                      70
#define IDW_CHILD8                      71
#define IDW_CHILD9                      72
#define IDW_CHILD10                     73
#define IDW_FILE_MRU_FILE1              75
#define IDW_FILE_MRU_FILE2              76
#define IDW_FILE_MRU_FILE3              77
#define IDW_FILE_MRU_FILE4              78
#define IDW_FILE_MRU_FILE5              79
#define IDW_FILE_MRU_FILE6              80
#define IDW_FILE_MRU_FILE7              81
#define IDW_FILE_MRU_FILE8              82
#define IDW_FILE_MRU_FILE9              83
#define IDW_FILE_MRU_FILE10             84
#define IDW_FILE_MRU_FILE11             85
#define IDW_FILE_MRU_FILE12             86
#define IDW_FILE_MRU_FILE13             87
#define IDW_FILE_MRU_FILE14             88
#define IDW_FILE_MRU_FILE15             89
#define IDW_FILE_MRU_FILE16             90
#define IDW_SPLITH                      91
#define IDW_SPLITV                      92
#define IDW_TRACK4WAY                   93
#define IDW_SDBOTTOM                    94
#define IDW_SDCENTER                    95
#define IDW_SDLEFT                      96
#define IDW_SDMIDDLE                    97
#define IDW_SDRIGHT                     98
#define IDW_SDTOP                       99
#define IDD_DIALOG1                     101
#define IDC_RADIO1                      110
#define IDC_RADIO2                      111
#define IDC_RADIO3                      112
#define IDC_CHECK1                      113
#define IDC_CHECK2                      114
#define IDC_CHECK3                      115
#define IDC_EDIT1                       120
#define IDC_LIST1                       121
#define IDC_BUTTON1                     122
#define IDC_RICHEDIT1                   123
#define IDC_STATIC1                     130
#define IDC_STATIC2                     131
#define IDC_STATIC3                     132
#define IDC_STATICGRID1                 132
#define IDC_HOTKEY1                     140
#define IDB_BITMAP1                     150
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           130
#endif
#endif
