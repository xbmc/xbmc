Grid Example
==============
This program simply displays a Grid in a dialog. It might prove a useful
starting point for your own Grid based projects. 


Features demonstrated in this example
=====================================
* Using a Grid as an application



About Grid
=============

