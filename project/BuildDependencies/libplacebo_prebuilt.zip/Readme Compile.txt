

meson build -Ddemos=false -Dopengl=disabled -Dd3d11=enabled -Dbuildtype=debug -Ddefault_library=shared -Dlcms=enabled -Dlibdovi=enabled -Dxxhash=enabled
ninja -Cbuild

and this to produce the lib from vstudio x64 command prompt
used gendef libplacebo-354.dll
lib /def:libplacebo-354.def /machine:x64 /out:libplacebo-354.lib



Where to extract the files

libplacebo-354.lib
project\BuildDependencies\x64\lib

dlls files in
project\BuildDependencies\x64\bin

libplacebo folder in
project\BuildDependencies\mingwlibs\x64\include