#
#      Copyright (C) 2005-2008 Team XBMC
#      http://www.xbmc.org
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import sys, urllib, re, xbmcgui, xbmc, os

baseurl = 'http://www.lachainemeteo.com/ImagesLCM/franNebP'
baseurl2 = 'http://www.lachainemeteo.com/ImagesLCM/franTmpP'

dossier = 'Q:\\'
ACTION_SHOW_INFO = 11
ACTION_STOP = 13
ACTION_PREVIOUS_MENU = 10

nomFichier = ''

print 'Demarrage'

class Window(xbmcgui.Window):

	def __init__(self):
		self.strAction = xbmcgui.ControlLabel(100, 100, 200, 200, '', 'font13')
		self.addControl(self.strAction)
		global compteur
		compteur = 0
	
	def onAction(self, action):
		#print('recieved action with number:' + str(action))

		if action == ACTION_SHOW_INFO:
			global compteur
			if compteur == 0:
				print 'ajout compteur 1'
				self.chargement('meteoJa',0,'PM')
				compteur = 1
			elif compteur == 1:
				print 'ajout compteur 2'
				self.chargement('meteoJb',1,'AM')
				compteur = 2
			elif compteur == 2:
				print 'ajout compteur 2'
				self.chargement('meteoJc',1,'PM')
				compteur = 3
			
			if action == ACTION_STOP:
				self.sortir()
			
			if action == ACTION_PREVIOUS_MENU:
				self.sortir()

	def chargement(self,nomFile,journee,periode):
		#self.strAction.setLabel('Chargement')
		nomFichier = nomFile +'1'
		global url
		url = baseurl + str(journee) + periode + '.jpg'
		self.downloadURL(url,nomFichier)
		global localfile
		localfile = dossier + nomFichier + ".jpg"
		self.addControl(xbmcgui.ControlImage(30,120,320,300, localfile))
		nomFichier2 = nomFile +'2'
		global url2
		url2 = baseurl2 + str(journee) + periode + '.jpg'
		self.downloadURL(url2,nomFichier2)
		global localfile2
		localfile2 = dossier + nomFichier2 + ".jpg"
		self.addControl(xbmcgui.ControlImage(345,120,330,300, localfile2))
		self.supFichier(localfile)
		self.supFichier(localfile2)


	def sortir(self):
		self.strAction.setLabel('Au revoir')
		self.close()

	def downloadURL(self,fichier,nom):        
		try:
			loc = urllib.URLopener()
			loc.retrieve(fichier, dossier + nom + ".jpg")
			#print 'download ok'
			#self.strAction.setLabel('download ok')
		
		except:
			print 'Erreur'
			self.strAction.setLabel('download failed')

	def supFichier(self,fichier):
		if os.path.isfile(fichier):
			os.remove(fichier)
			#print 'fichier sup'


########## main ##########
meteo = Window()

c2 = xbmcgui.ControlLabel(300, 50, 200, 200, u'text', 'font14', '0xFF0080C0')
c2.setLabel('Pr�visions m�t�o')
meteo.addControl(c2)
c3 = xbmcgui.ControlLabel(260, 80, 200, 200, u'text', 'font14', '0xFFFF80C0')
c3.setLabel('offert par La chaine m�t�o')
meteo.addControl(c3)
c4 = xbmcgui.ControlLabel(250, 440, 200, 200, u'text', 'font14')
c4.setLabel('Touche blanche pour changer')
meteo.addControl(c4)
c5 = xbmcgui.ControlLabel(300, 480, 200, 200, u'text', 'font14')
c5.setLabel('BACK pour quitter')
meteo.addControl(c5)
c6 = xbmcgui.ControlLabel(260, 510, 200, 200, u'text', 'font14', '0xFF666666')
c6.setLabel('Code : alx5962@yahoo.com')
meteo.addControl(c6)

meteo.chargement('meteoJ',0,'AM')
meteo.doModal()
del meteo
