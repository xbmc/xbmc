import xbmcgui
import os

KEY_BUTTON_BACK = 275
KEY_KEYBOARD_ESC = 61467
remote_DEBUG = 1

__title__ = "Window XML Example"

"""
    Problems At The Moment
    - No way to include Media/images with the script
    - 'Exiting Problem' if you do use <onclick> in the xml (builtins) [i find u have to activatewindow(13000) 'usally' to show the script again then ESC/BACK to close
    - Going to onright or onsomething ot id 50 doesn't work if you change teh view type, however it works if you use SetFocus(50)

    Notes)
        The xml included in teh defualt skin shouldn't rely on includes and defaults. (maybe except for fonts until XBMC has better ttf loading ;)
        The idea is the Skinners actually have the WindowXMLExample or what ever ur script xml calls in their skin. so theres non of this 'put the xml in the skin'
        Maybe a uniform name would be good like Script_WindowXMLExample,Script_AMT_Main.xml)
"""

"""
    xbmcgui.WindowXML()
    xbmcgui.WindowXML().onInit(self)
    xbmcgui.WindowXML().onAction(self,action)
    xbmcgui.WindowXML().onClick(self,controlID)		Replacement for onControl
    xbmcgui.WindowXML().onFocus(self,controlID)
"""

scriptPath = os.getcwd().replace(';','')
import pydoc
pydoc.writedoc(xbmcgui)
class WindowXMLExample(xbmcgui.WindowXML):
    def __init__(self,strXMLname, strFallbackPath):
        self.url = "http://xboxmediacenter.com"

    def onInit(self):
        """
            This function has been implemented and works
            The Idea for htis function is to be used to get inital data and populate lists
        """
        print "onInit(): Window Initalized"
        for x in range(0,10):
            self.addItem(xbmcgui.ListItem(("Hello %i" % x),("World %i" % x), "defaultVideo.png", "defaultVideoBig.png"))
            self.addItem(xbmcgui.ListItem(("Test %i"  % x),("Hey %i"   % x), "defaultVideo.png", "defaultVideoBig.png"))
        # now update the list
        self.button = self.getControl(99) # Example of getting a control based on ID 
        self.button.setLabel('Add List Way 2', 'font14', '0xFFFFFFFF', '0xFFFF3300', '0xFF000000')  # changing the control after its on screen

    def onAction(self, action):
        """"
            onAction in WindowXML works same as on a Window or WindowDialog its for keypress/controller buttons etc
            This function has been implemented and works
        """
        buttonCode =  action.getButtonCode()
        actionID   =  action.getId()
        print "onAction(): actionID=%i buttonCode=%i" % (actionID,buttonCode)
        if (buttonCode == KEY_BUTTON_BACK or buttonCode == KEY_KEYBOARD_ESC or buttonCode == 61467):
            self.close()

    def onClick(self, controlID):
        """
            onClick(self, controlID) is the replacement for onControl. It gives an interger.
            This function has been implemented and works
        """
        print "onclick(): control %i" % controlID
        if (controlID == 7):
            xbmcgui.Dialog().ok(__title__ + ": About","Example Script coded by Donno :D","WindowXML Class coded by Donno","With help from Spiff :)")
        elif (controlID == 13):
            self.clearList()
        elif (controlID == 99):
            for x in range(0,10):
                self.addItem(xbmcgui.ListItem(("Hello %i" % x),("World %i" % x), "defaultVideo.png", "defaultVideoBig.png"),0)
                self.addItem(xbmcgui.ListItem(("Test %i"  % x),("Hey %i"   % x), "defaultVideo.png", "defaultVideoBig.png"),0)
            self.refreshList()

    def onFocus(self, controlID):
        """"
            onFocus(self, int controlID)
            This function has been implemented and works
        """
        print "onFocus(): control %i" % controlID
        if (controlID == 5):
            print 'The control with id="5" just got focus'

if __name__ == '__main__':
    w = WindowXMLExample("Script_WindowXMLExample.xml",os.path.join(scriptPath,'DefaultSkin'))
    w.doModal()
    del w