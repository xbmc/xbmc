# -*- Mode: Python; tab-width: 4 -*-

import os
import time
import string
import sys

# for now, just build a date string into the name.

if len(sys.argv) > 1:
	package = sys.argv[1]
else:
	package = 'medusa'

date_string = time.strftime ('%Y%m%d', time.gmtime(time.time ()))

dist_name = '%s-%s' % (package, date_string)
here = os.getcwd()
os.symlink (here, '../%s' % dist_name)
os.chdir ('..')
os.system ('/usr/local/bin/gtar --dereference --exclude CVS -zcvf /tmp/%s.tar.gz %s' % (dist_name, dist_name))
os.unlink (dist_name)
os.chdir (here)
