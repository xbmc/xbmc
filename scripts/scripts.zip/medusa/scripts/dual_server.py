# -*- Mode: Python; tab-width: 4 -*-

# This is something you might want to use on a machine running Windows
# NT or Windows 95 - simultaneously publish the directory 'd:/public'
# via http and ftp, on the standard ports.

import http_server

hs = http_server.http_server (
    'd:/public',
    80
    )

fs = ftp_server.FTP_SERVER (
    ftp_server.dummy_authorizer ('d:/public'),
    port = 21
    )
    
