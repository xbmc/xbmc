# -*- Mode: Python; tab-width: 4 -*-

import http_server

hs = http_server.http_server (
    '/usr/local/etc/httpd/docs',
    8080
    )
