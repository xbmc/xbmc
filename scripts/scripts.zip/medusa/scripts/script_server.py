# -*- Mode: Python; tab-width: 4 -*-

import sys
import http_server
import default_handler
import asyncore
import logger
import script_handler
import filesys

PUBLISHING_ROOT='/home/medusa'

class sample_input_collector:
    def __init__ (self, request, length):
	self.request = request
	self.length = length
	
    def collect_incoming_data (self, data):
	print 'data from %s: <%s>' % (self.request, repr(data))

class post_script_handler (script_handler.script_handler):

    def handle_request (self, request):
	if request.command == 'post':
	    ic = sample_input_collector (request)
	    request.collector = ic
	    print request.header

	return script_handler.script_handler.handle_request (self, request)

lg = logger.file_logger (sys.stdout)
fs = filesys.os_filesystem (PUBLISHING_ROOT)
dh = default_handler.default_handler (fs)
ph = post_script_handler (fs)
hs = http_server.http_server ('', 8081, logger_object = lg)

hs.install_handler (dh)
hs.install_handler (ph)

asyncore.loop()
