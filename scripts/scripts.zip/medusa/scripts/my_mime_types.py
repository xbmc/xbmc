# -*- Mode: Python; tab-width: 4 -*-

# extend the global builtin MIME type table.

import mime_type_table
m = mime_type_table.content_type_map

m['py'] = 'application/x-python'
m['fnord'] = 'application/x-fnord'

# etc...
