import xbmcgui, sys
from os import path

ExtrasPath		=	sys.path[0] +  '\\extras\\'
sys.path.append(ExtrasPath + '\\lib')
	

ImagePath 		= ExtrasPath + 'images'
SkinPath			= ExtrasPath + 'skins\\'

class windowOverlay(xbmcgui.Window):
	def __init__(self):
		import  guibuilder
		guibuilder.GUIBuilder(self,  SkinPath + 'Window_test.xml', ImagePath)
		if (not self.SUCCEEDED): self.exitScript()
		for item in range(20):
			l = xbmcgui.ListItem('This is item #%d of 20 items' % (item +1,), 'item# %d' % (item +1,), '', 'defaultAlbumCover.png')
			self.controls[30].addItem(l)
		
	def exitScript(self):
		self.close()
	
	def onControl(self, control):
		if (control == self.controls[10]):
			self.controls[20].reset()
			self.controls[20].addLabel('You pressed button ID#10')
		elif (control == self.controls[11]):
			self.controls[20].reset()
			self.controls[20].addLabel('You pressed button ID#11')
		elif (control == self.controls[12]):
			self.controls[20].reset()
			self.controls[20].addLabel('You pressed button ID#12')
		elif (control == self.controls[13]):
			self.controls[20].reset()
			self.controls[20].addLabel('You pressed button ID#13')
		elif (control == self.controls[14]):
			self.controls[20].reset()
			self.controls[20].addLabel('You pressed button ID#14')
		elif (control == self.controls[15]):
			self.controls[20].reset()
			self.controls[20].addLabel('You pressed button ID#15')
		elif (control == self.controls[4]):
			xbmc.executebuiltin('XBMC.Mute')
			#print '500', self.visibility[500], xbmc.getCondVisibility(self.visibility[500])
			#print '501', self.visibility[501], xbmc.getCondVisibility(self.visibility[501])
			#print 'Muted:', xbmc.getCondVisibility('player.muted')
			xbmc.sleep(50)
			self.controls[500].setVisible(xbmc.getCondVisibility(self.visibility[500]))
			self.controls[501].setVisible(xbmc.getCondVisibility(self.visibility[501]))
		elif (control == self.controls[30]):
			self.controls[20].reset()
			a = self.controls[30].getSelectedItem().getLabel()
			self.controls[20].addLabel(a)

	def onAction(self, action):
		if action == 10: self.close()
		c = self.getFocus()
		if (c != self.controls[30]): 
			self.controls[30].controlLeft(c)
			self.controls[30].controlRight(c)
			

MyDisplay = windowOverlay()
if (MyDisplay.SUCCEEDED): MyDisplay.doModal()
del MyDisplay