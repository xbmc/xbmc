import xbmcgui, sys
from os import path

ExtrasPath		=	sys.path[0] +  '\\extras\\'
sys.path.append(ExtrasPath + '\\lib')
	

ImagePath 		= ExtrasPath + 'images'
SkinPath			= ExtrasPath + 'skins\\'

class windowOverlay(xbmcgui.WindowDialog):
	def __init__(self):
		import guibuilder
		guibuilder.GUIBuilder(self,  SkinPath + 'WindowDialog_test.xml', ImagePath)
		if (not self.SUCCEEDED): self.exitScript()
		else:
			for item in range(20):
				l = xbmcgui.ListItem('This is item #%d of 20 items' % (item +1,), 'item# %d' % (item +1,), '', 'defaultAlbumCover.png')
				self.controls[30].addItem(l)
		
	def exitScript(self):
		self.close()
	
	def movePad(self, x, y):
		xbmcgui.lock()
		self.coordinates[0] += x
		self.coordinates[1] += y
		for k in self.controls:
			self.controls[k].setPosition(self.positions[k][0] + self.coordinates[0], self.positions[k][1] + self.coordinates[1])
		xbmcgui.unlock()
	
	def onControl(self, control):
		if (control == self.controls[10]):
			self.movePad(0, -5)
		elif (control == self.controls[11]):
			self.movePad(0, 5)
		elif (control == self.controls[12]):
			self.movePad(-5, 0)
		elif (control == self.controls[13]):
			self.movePad(5, 0)
		elif (control == self.controls[14]):
			self.controls[20].reset()
			self.controls[20].addLabel('You pressed button ID#14')
		elif (control == self.controls[15]):
			self.controls[20].reset()
			self.controls[20].addLabel('You pressed button ID#15')
		elif (control == self.controls[4]):
			xbmc.executebuiltin('XBMC.Mute')
			#print '500', self.visibility[500], xbmc.getCondVisibility(self.visibility[500])
			#print '501', self.visibility[501], xbmc.getCondVisibility(self.visibility[501])
			#print 'Muted:', xbmc.getCondVisibility('player.muted')
			xbmc.sleep(50)
			self.controls[500].setVisible(xbmc.getCondVisibility(self.visibility[500]))
			self.controls[501].setVisible(xbmc.getCondVisibility(self.visibility[501]))
		elif (control == self.controls[30]):
			self.controls[20].reset()
			a = self.controls[30].getSelectedItem().getLabel()
			self.controls[20].addLabel(a)

	def onAction(self, action):
		if action == 10: self.close()
		c = self.getFocus()
		if (c != self.controls[30]): 
			self.controls[30].controlLeft(c)
			self.controls[30].controlRight(c)
			

MyDisplay = windowOverlay()
if (MyDisplay.SUCCEEDED): MyDisplay.doModal()
del MyDisplay