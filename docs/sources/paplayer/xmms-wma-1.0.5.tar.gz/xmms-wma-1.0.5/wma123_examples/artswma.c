/**
 * 2004
 * Example mini WMA player by McMCC <mcmcc@mail.ru>
 * Use aRtsD sound server from KDE...
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <artsc.h>

#ifdef HAVE_AV_CONFIG_H
#undef HAVE_AV_CONFIG_H
#endif

#include "avcodec.h"
#include "avformat.h"
#include "playlist.h"

#define ST_BUFF 2048

void audio_decode(const char *filename)
{
    AVCodec *codec;
    AVPacket pkt;
    AVCodecContext *c= NULL;
    AVFormatContext *ic= NULL;
    arts_stream_t stream;
    int out_size, size, len, err, i;
    int tns, thh, tmm, tss, st_buff;
    uint8_t *outbuf, *inbuf_ptr, *s_outbuf;
    FifoBuffer f;

    err = av_open_input_file(&ic, filename, NULL, 0, NULL);
    if (err < 0) {
        printf("Error file %s\n", filename);
	exit(0);
    }

    for(i = 0; i < ic->nb_streams; i++) {
        c = &ic->streams[i]->codec;
        if(c->codec_type == CODEC_TYPE_AUDIO)
            break;
    }

    av_find_stream_info(ic);

    codec = avcodec_find_decoder(c->codec_id);        
    if (!codec) {
        fprintf(stderr, "codec not found\n");
        exit(1);
    }
    /* open it */
    if (avcodec_open(c, codec) < 0) {
        fprintf(stderr, "could not open codec\n");
        exit(1);
    }

    st_buff = ST_BUFF;

    outbuf = malloc(AVCODEC_MAX_AUDIO_FRAME_SIZE);
    s_outbuf = malloc(st_buff);

        fprintf(stderr, "\n\n");
    dump_format(ic, 0, filename, 0);
    if (ic->title[0] != '\0')
        fprintf(stderr, "Title: %s\n", ic->title);
    if (ic->author[0] != '\0')
        fprintf(stderr, "Author: %s\n", ic->author);
    if (ic->album[0] != '\0')
        fprintf(stderr, "Album: %s\n", ic->album);
    if (ic->year != 0)
        fprintf(stderr, "Year: %d\n", ic->year);
    if (ic->track != 0)
        fprintf(stderr, "Track: %d\n", ic->track);
    if (ic->genre[0] != '\0')
        fprintf(stderr, "Genre: %s\n", ic->genre);
    if (ic->copyright[0] != '\0')
        fprintf(stderr, "Copyright: %s\n", ic->copyright);
    if (ic->comment[0] != '\0')
        fprintf(stderr, "Comments: %s\n", ic->comment);

    if (ic->duration != 0)
    {
	tns = ic->duration/1000000LL;
	thh = tns/3600;
	tmm = (tns%3600)/60;
	tss = (tns%60);
	fprintf(stderr, "Time: %2d:%02d:%02d\n", thh, tmm, tss);
    }

	tns = 0;
	thh = 0;
	tmm = 0;
	tss = 0;
    
    fprintf(stderr, "\n");
    
    stream = arts_play_stream(c->sample_rate, 16, c->channels, "artswma");

    for(;;){

	if (av_read_frame(ic, &pkt) < 0)
	    break;

	size = pkt.size;
	inbuf_ptr = pkt.data;
	tns = pkt.pts/1000000LL;
	thh = tns/3600;
	tmm = (tns%3600)/60;
	tss = (tns%60);
	fprintf(stderr, "Play Time: %2d:%02d:%02d bitrate: %d kb/s\r", thh, tmm, 
		tss, c->bit_rate / 1000);
        if (size == 0)
            break;

        while (size > 0) {
            len = avcodec_decode_audio(c, (short *)outbuf, &out_size, 
                                       inbuf_ptr, size);
	    	
            if (len < 0) {
		break;
            }
	    
            if (out_size <= 0) {
		continue;
	    }
            if (out_size > 0) {
                fifo_init(&f, out_size*2);
                fifo_write(&f, outbuf, out_size, &f.wptr);
                while(fifo_read(&f, s_outbuf, st_buff, &f.rptr) == 0)
                {
		    err = arts_write(stream, s_outbuf, st_buff);	
		    if(err < 0)
		    {
			fprintf(stderr, "arts_write error: %s\n", arts_error_text(err));
			return;
		    }	    
                }
                fifo_free(&f);
            }
            size -= len;
            inbuf_ptr += len;
	        if (pkt.data)
        	    av_free_packet(&pkt);
        }

    }

    fprintf(stderr, "\n");
    arts_close_stream(stream);

    if(outbuf)
	free(outbuf);
    if(s_outbuf)
        free(s_outbuf);

    avcodec_close(c);
    av_close_input_file(ic);
}

int main(int argc, char **argv)
{
    int errorcode;
    char **playlist_array;
    playlist_t *playlist;
    int items, i;
    struct stat stat_s;
    
    if(!argv[1])
    {
	fprintf(stderr,"\nUse %s file.wma\n\n", argv[0]);
	exit(0);
    }
    
    errorcode = arts_init();
    if (errorcode < 0)
    {
        fprintf(stderr, "arts_init error: %s\n", arts_error_text(errorcode));
        return 1;
    }

    avcodec_init();

    avcodec_register_all();
    av_register_all();
    
    playlist = playlist_create();
    for (i = 1; i < argc; i++) {
    if (stat(argv[i], &stat_s) == 0) {
        if (S_ISDIR(stat_s.st_mode)) {
            if (playlist_append_directory(playlist, argv[i]) == 0)
                fprintf(stderr, "Warning: Could not read directory %s.\n", argv[i]);
        } else {
            playlist_append_file(playlist, argv[i]);
        }
    } else
        playlist_append_file(playlist, argv[i]);
    }

    if (playlist_length(playlist)) {
        playlist_array = playlist_to_array(playlist, &items);
        playlist_destroy(playlist);
        playlist = NULL;
    } else
        exit (1);

    i = 0;
    while ( i < items) {
        audio_decode(playlist_array[i]);
        i++;
    }

    playlist_array_destroy(playlist_array, items);
    arts_free();
    exit (0);
}
