#ifndef __XMMS_WMA_C__
#define __XMMS_WMA_C__

#include <stdlib.h>
#include <memory.h>

#ifdef HAVE_AV_CONFIG_H
#undef HAVE_AV_CONFIG_H
#endif

#include "avcodec.h"
#include "avformat.h"

struct wma_info
{
  int wma_decode;
  int wma_seekpos;
  int wma_idx;
  AVCodecContext *c;
  AVFormatContext *ic;
  uint8_t pcm_buf[(AVCODEC_MAX_AUDIO_FRAME_SIZE * 3) / 2];
  int pcm_buf_remaining;
  int pcm_buf_i;
};

void DLL_Init(void)
{
  avcodec_init();
  avcodec_register_all();
  av_register_all();
}

int DLL_FillBuffer(unsigned int hnd, char* out_buffer, int out_length)
{
  int result;
  struct wma_info* w = (struct wma_info*) hnd;
  
  if (!w->wma_decode)
    return 0;
  
  uint8_t *inbuf_ptr;
  int out_size, size, len;
  AVPacket pkt;
    
	if (w->wma_seekpos != -1)
	{
	  av_seek_frame(w->ic, w->wma_idx, w->wma_seekpos * 1000LL);
	  w->wma_seekpos = -1;
	  w->pcm_buf_remaining = 0;
	}
  
  // If there's data in the buffer that we did not yet return to xbmc, do it
  // otherwise call ffmpeg
  if (w->pcm_buf_remaining == 0)
  {
    if (av_read_frame(w->ic, &pkt) < 0) return 0;

    size = pkt.size;
    inbuf_ptr = pkt.data;

    w->pcm_buf_remaining = sizeof(w->pcm_buf);
    avcodec_decode_audio(w->c, (short *)w->pcm_buf, &w->pcm_buf_remaining, pkt.data, pkt.size);
    
    w->pcm_buf_i = 0;
  
    if (pkt.data) av_free_packet(&pkt);
  }
  
  if (out_length < w->pcm_buf_remaining)
    result = out_length;
  else
    result = w->pcm_buf_remaining;
 
  memcpy(out_buffer, &w->pcm_buf[w->pcm_buf_i], result);
  w->pcm_buf_i += result;
  w->pcm_buf_remaining -= result;
  
  return result;
}

void* DLL_LoadFile(const char *filename, long long* totalTime, int *sampleRate, int* bitsPerSample, int *channels) 
{
  struct wma_info* w = (struct wma_info*) malloc(sizeof(struct wma_info));
  
  AVCodec *codec;
    
  if (av_open_input_file(&w->ic, filename, NULL, 0, NULL) < 0) 
  {
    free(w);
    return 0;
  }
    
  for (w->wma_idx = 0; w->wma_idx < w->ic->nb_streams; w->wma_idx++) 
  {
    w->c = &w->ic->streams[w->wma_idx]->codec;
    if (w->c->codec_type == CODEC_TYPE_AUDIO) 
      break;
  }

  av_find_stream_info(w->ic);

  codec = avcodec_find_decoder(w->c->codec_id);

  if (!codec)
  {
    av_close_input_file(w->ic);
    free(w); 
    return 0;
  }
	
  if (avcodec_open(w->c, codec) < 0)
  {
    av_close_input_file(w->ic);
    free(w); 
    return 0;
  }
	    	    
  w->wma_seekpos = -1;
  w->wma_decode = 1;
  w->pcm_buf_remaining = 0;
    
  *totalTime = w->ic->duration/1000;
  *sampleRate = w->c->sample_rate;
  *bitsPerSample = w->c->bit_rate/8000;
  *channels = w->c->channels;
  
  return w;
}

void DLL_UnloadFile(void* hnd) 
{
  struct wma_info* w = (struct wma_info*) hnd;

  avcodec_close(w->c);
  av_close_input_file(w->ic);
  free(w);    
}	

unsigned long DLL_Seek(void* hnd, unsigned long time) 
{
  struct wma_info* w = (struct wma_info*) hnd;
  
  if (w->wma_decode)
    w->wma_seekpos = time;
}

#endif
