#!/bin/bash 

if [ "$XBMC_ROOT" == "" ]; then
   echo you must define XBMC_ROOT to the root source folder
   exit 1
fi

ld -o libid3tag-xbmc.so --export-dynamic -shared  --whole-archive .libs/libid3tag.a `grep __wrap $XBMC_ROOT/xbmc/cores/DllLoader/exports/wrapper.c | grep -v bash | awk -F"__wrap_"  '{print $2}' | awk -F"(" '{out=out"--wrap "$1" "} END {print out}'` 


