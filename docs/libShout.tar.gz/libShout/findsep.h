#ifndef __FINDSEP_H__
#define __FINDSEP_H__

#include "types.h"

extern error_code findsep_silence(const u_char* mpgbuf, long mpgsize, u_long* psilence);
#endif //__FINDSEP_H__
