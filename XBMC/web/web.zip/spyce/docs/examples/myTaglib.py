from spyceTag import spyceTagLibrary, spyceTagPlus

class tag_foo(spyceTagPlus):
  name = 'foo'
  def syntax(self):
    self.syntaxPairOnly()
    self.syntaxExist('val')
    self.syntaxNonEmpty('val')
  def begin(self, val):
    val = self.contextEval(val)
    self.getOut().write('<font size="%s"><b>' % str(val))
    return 1
  def end(self):
    self.getOut().write('</b></font><br>')

class myTaglib(spyceTagLibrary):
  tags = [
    tag_foo, 
  ]

